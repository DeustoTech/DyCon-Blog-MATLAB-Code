function stopani(obj,event,h)
%STOPANI Summary of this function goes here
%   Detailed explanation goes here
    h.DA.twoD.ax1.Tag = 'stop';
end

